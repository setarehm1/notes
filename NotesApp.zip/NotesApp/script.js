// const button = document.querySelector(".addNote");
// const desc = document.querySelector("#note");
// const title = document.querySelector("#title");
// const notesContainer = document.querySelector(".notes-container");
// let notes = [];

// button.addEventListener("click", (e) => {
//   const titleText = title.value;
//   const description = desc.value;
//   const target = e.target;

//   if (titleText.trim() && description.trim()) {
//     notes.push({ title: titleText, description });
//   }

//   viewNotes();
// });

// const viewNotes = () => {
//   notesContainer.innerHTML = "";
//   if (notes.length) {
//     notes.forEach((note, index) => {
//       notesContainer.innerHTML += `
//     <div class="note">
//     <h2>${note.title}</h2>
//     <p>${note.description}</p>
//     <button id="${index}" onClick="deleteNode(this.id)">Delete</button>
//   </div>
//     `;
//     });
//   }
// };

// const deleteNode = (elem) => {
//   notes.splice(elem, 1);
//   viewNotes();
// };

let addButton = document.querySelector(".addNote");
let titleElem = document.getElementById("title");
let descElem = document.getElementById("note");
let container = document.querySelector(".notes-container");
let notesArr = [];

addButton.addEventListener("click", onClick);

function onClick() {
  let titleValue = titleElem.value;
  let description = descElem.value;

  if (title && description) {
    notesArr.push({ title: titleValue, desc: description });
  }

  viewNotes();
}

function viewNotes() {
  container.innerHTML = "";
  notesArr.forEach((element) => {
    container.innerHTML += `
            <div class="note">
              <h2>${element.title}</h2>
                <p>
                  ${element.desc}
                </p>
                <button id="delete">Delete</button>
            </div> 
    `;
  });
}
